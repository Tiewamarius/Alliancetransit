@extends('layouts.admin')
@section('title','EnvoiColis')
@section('content')

<div class="container mt-4">
    <h2>Créer une expédition</h2>
    @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif

    <form method="POST" action="{{ route('storeExpedition') }}">
        @csrf
        
        <h4>Information du client</h4>
        <div class="card">
            <div class="card-body">
                <div class="row mb-3">
                    <div>
                        <input type="hidden" id="nom_client" name="code_client" value="{{$code_client}}">
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating">
                            <label for="floatingInputGrid">Nom</label>
                            <input type="name" name="nom_client" class="form-control" id="floatingInputGrid" placeholder="Nom du client" value="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="telephone_client" class="form-label">Téléphone</label>
                        <input type="tel" id="telephone_client" name="numero_client" class="form-control" value=""placeholder="N° telephone">
                    </div>
                    <div class="col-md-6">
                        <label for="email_client" class="form-label">Email</label>
                        <input type="email" id="email_client" name="email_client" class="form-control" value=""></div>
                    <div class="col-md-6">
                        <label for="adresse_client" class="form-label">Adresse</label>
                        <input type="text" id="adresse_client" name="adresse_client" class="form-control" value="">
                    </div>
                </div>
            </div>
        </div>
        <br>
        <h4>Information du Expediteur</h4>
        <div class="card">
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-floating">
                            <label for="floatingInputGrid">Nom Expediteur</label>
                            <input type="text" name="nom_expediteur" class="form-control" id="floatingInputGrid" placeholder="Nom de l'Expediteur" value="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="telephone_client" name="numero_expediteur" class="form-label">Téléphone</label>
                        <input type="tel" id="telephone_client" name="numero_expediteur" class="form-control" value="">
                    </div>
                    <div class="col-md-6">
                        <label for="email_client" name="email_expediteur" class="form-label">Email_expediteur</label>
                        <input type="email" id="email_client" name="email_expediteur" class="form-control" value="">
                    </div>
                    <div class="col-md-6">
                        <label for="adresse_client" name="adresse_expediteur" class="form-label">Adresse_expediteur</label>
                        <input type="text" id="adresse_client" name="adresse_expediteur" class="form-control" value="">
                    </div>
                </div>
            </div>
        </div>
        <br>
        <h4>Information du Destinataire</h4>
        <div class="card">
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-floating">
                            <label for="floatingInputGrid">Destinataire</label>
                            <input type="text" name="nom_destinataire" class="form-control" id="floatingInputGrid" placeholder="Nom du destinataire" value="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="telephone_client" class="form-label">Téléphone</label>
                        <input type="text" id="telephone_client" name="numero_destinataire" class="form-control" value="">
                    </div>
                    <div class="col-md-6">
                        <label for="email_client" name="emai_destin" class="form-label">Email</label>
                        <input type="email" id="email_client" name="email_destinataire" class="form-control" value="">
                    </div>
                    <div class="col-md-6">
                        <label for="adresse_client" name="adresse" class="form-label">Adresse</label>
                        <input type="text" id="adresse_client" name="adresse_destinataire" class="form-control"  >

                    </div>
                </div>
            </div>

        </div>
        <br>
        <h4>Information du colis</h4>
        <div class="card">
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="nom_client" class="form-label">Code de suivi</label>
                        <input type="text" id="nom_client" name="numeroSuivi" value="{{$code_suivi}}" class="form-control"  >
                    </div>
                    <div class="col-md-6">
                        <label for="prenom_client" class="form-label">Desigation</label>
                        <input type="text" id="prenom_client" name="designation" class="form-control"  >
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="telephone_client" class="form-label">N° CONTENEUR</label>
                        <input type="text" id="telephone_client" name="numeroConteneur" class="form-control"  >
                    </div>
                    <div class="col-md-6">
                        <label for="email_client" class="form-label">Type de service</label>
                        <input type="text" id="email_client" name="typeService" class="form-control">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="telephone_client" class="form-label">Date-Enlevement</label>
                        <input type="datetime-local" id="telephone_client" name="dateEnlev" class="form-control"  >
                    </div>
                    <div class="col-md-6">
                        <label for="telephone_client" class="form-label">Date-Livraison</label>
                        <input type="datetime-local" id="telephone_client" name="dateLivr" class="form-control"  >
                    </div>
                </div>
                <div class="row mb-3">
                    <div  class="col-md-6">
                        <label for="statut" class="form-label">STATUS D'EXP.</label>
                        <select name="status" id="statut" class="form-select">
                            <option value="en preparation">En prepartion</option>
                            <option value="en transit" selected>En transit</option>
                            <option value="en stock">En stock</option>
                            <option value="terminé">Terminé</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="statut" class="form-label">Paiement</label>
                        <select name="status"  id="statut" class="form-select">
                            <option value="avance">Avance</option>
                            <option value="soldé" selected>soldé</option>
                            <option value="crédit">crédit</option>
                        </select>
                    </div>
                </div>
            <div class="row mb-3" style="float: right;">
                <button type="submit" class="btn btn-success">EXPEDIER</button>
            </div>
            </div>
        </div>
        </div>
    </div>
</form>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
@endsection