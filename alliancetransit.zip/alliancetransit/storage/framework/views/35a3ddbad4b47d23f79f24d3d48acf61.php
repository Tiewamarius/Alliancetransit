<?php $__env->startSection('title','AjoutConteneur'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Ajouter un Conteneur</h2>
    <div class="card">
        <div class="card-body"><?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('storeConteneur')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="container_number" class="form-label">Numéro du Conteneur *</label>
                    <input type="text" name="container_number" id="container_number" class="form-control" placeholder="Numéro du Conteneur" required>
                </div>

                <div class="mb-3">
                    <label for="type" class="form-label">Type *</label>
                    <select name="type" id="type" class="form-select" required>
                        <option value="">Choisir un type</option>
                        <option value="Conteneur standard">Conteneur standard</option>
                        <option value="Conteneur Réfrigéré">Conteneur Réfrigéré</option>
                        <option value="Conteneur Open Top">Conteneur Open Top</option>
                        <option value="Conteneur High Cube">Conteneur High Cube</option>
                        <option value="Conteneur Flat Rack">Conteneur Flat Rack</option>
                        <option value="Conteneur Citerne">Conteneur Citerne</option>
                        <option value="Le conteneur- stockage">Le conteneur- stockage</option>
                        <!-- Ajouter les options dynamiquement -->
                    </select>
                </div>

                <div class="mb-3">
                    <label for="location" class="form-label">Emplacement *</label>
                    <input type="text" name="location" id="location" class="form-control" placeholder="Emplacement" required>
                </div>

                <div class="d-flex justify-content-end">
                    <a href="<?php echo e(url('admin.dashbord')); ?>" class="btn btn-light me-2">Abandonner</a>
                    <button type="submit" class="btn btn-primary">Créer</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alliancetransit\resources\views/admin/clients/AjoutConteneur.blade.php ENDPATH**/ ?>