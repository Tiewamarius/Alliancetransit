<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <h2 class="mb-4">Ajouter un Client</h2>
    
    <div class="card">
        <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('storeClient')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <div>
                        <input type="hidden" id="nom_client" name="code_client" value="<?php echo e($code_client); ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="nom_client" class="form-label">Nom</label>
                        <input type="text" id="nom_client" name="nom_client" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label for="prenom_client" class="form-label">Prénom</label>
                        <input type="text" id="prenom_client" name="prenom_client" class="form-control" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="telephone_client" class="form-label">Téléphone</label>
                        <input type="text" id="telephone_client" name="numero_client" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label for="email_client" class="form-label">Email</label>
                        <input type="email" id="email_client" name="email_client" class="form-control">
                    </div>
                </div>
                <div class="mb-3">
                    <label for="adresse_client" class="form-label">Adresse</label>
                    <input type="text" id="adresse_client" name="adresse_client" class="form-control" required>
                </div>
                <div class="text-end">
                    <button type="submit" class="btn btn-primary">Ajouter</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alliancetransit\resources\views/admin/clients/Ajoutclients.blade.php ENDPATH**/ ?>