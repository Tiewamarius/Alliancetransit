<?php $__env->startSection('title','EnvoiColis'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Liste des Clients</h1>
    <a href="<?php echo e(url('admin/Ajoutclients')); ?>" class="btn btn-primary mb-3">Ajouter un Client</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Ident.</th>
                <th>Nom</th>
                <th>Email</th>
                <th>Téléphone</th>
                <th>Adresse</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($client->code_client); ?></td>
                <td><?php echo e($client->nom_client); ?></td>
                <td><?php echo e($client->email_client); ?></td>
                <td><?php echo e($client->numero_client); ?></td>
                <td><?php echo e($client->adresse_client); ?></td>
                <td>
                    <a href="<?php echo e(route('clients.edit', $client->id)); ?>" class="btn btn-warning">Modifier</a>
                    <form action="<?php echo e(route('clients.destroy', $client->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr ?')">Supprimer</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alliancetransit\resources\views/admin/clients/allClients.blade.php ENDPATH**/ ?>