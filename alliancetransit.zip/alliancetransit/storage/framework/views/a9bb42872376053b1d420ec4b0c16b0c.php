
<footer class="bg-black text-center py-5">
            <div class="container px-5">
                <div class="text-white-50 small">
                    <div class="mb-2">&copy; Votre siteWeb 2025. tous Droits Reservé.</div>
                    <a href="#!">Contrat de confidentialité</a>
                    <span class="mx-1">&middot;</span>
                    <a href="#!">Terms</a>
                    <span class="mx-1">&middot;</span>
                    <a href="#!">FAQ</a>
                </div>
            </div>
        </footer><?php /**PATH C:\xampp\htdocs\alliancetransit\resources\views/layouts/partialsClients/footer.blade.php ENDPATH**/ ?>