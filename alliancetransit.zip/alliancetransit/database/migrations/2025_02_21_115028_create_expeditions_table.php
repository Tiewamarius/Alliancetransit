<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('expeditions', function (Blueprint $table) {
            $table->id();
            $table->string('code_client')->nullable();
            $table->unsignedBigInteger('client_id')->nullable();
            $table->string('nom_client')->nullable();
            $table->string('numero_client')->nullable();
            $table->string('email_client')->nullable();
            $table->string('adresse_client')->nullable();

            $table->unsignedBigInteger('expediteur_id')->nullable();
            $table->string('nom_expediteur')->nullable();
            $table->string('numero_expediteur')->nullable();
            $table->string('email_expediteur')->nullable();
            $table->string('adresse_expediteur')->nullable();

            $table->unsignedBigInteger('destinataire_id')->nullable();
            $table->string('nom_destinataire')->nullable();
            $table->string('numero_destinataire')->nullable();
            $table->string('email_destinataire')->nullable();
            $table->string('adresse_destinataire')->nullable();

            $table->string('numeroSuivi')->nullable();
            $table->string('designation')->nullable();
            $table->string('numeroConteneur')->nullable();
            $table->string('typeService')->nullable();
            $table->dateTime('dateEnlev')->nullable();
            $table->dateTime('dateLivr')->nullable();
            $table->enum('status', ['en preparation', 'en transit', 'en stock','terminé']); // Exemple de liste déroulante
            $table->enum('status', ['avance', 'soldé', 'credit']);// Exemple de liste déroulante
            $table->timestamps();

            $table->foreign('client_id')->references('id')->on('clients')->onDelete('set null');
            $table->foreign('expediteur_id')->references('id')->on('expediteurs')->onDelete('set null');
            $table->foreign('destinataire_id')->references('id')->on('destinataires')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('expeditions');
    }
};